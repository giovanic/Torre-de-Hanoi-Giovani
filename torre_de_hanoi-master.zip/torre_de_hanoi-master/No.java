/**
 * Write a description of class No here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class No<T>  
{
    private T valor;
    private No anterior;

    public No(){
    }

    public No(T valor){
        this.valor = valor;
    } 

    public T getValor(){
        return valor;
    } 

    public void setValor(T valor){
        this.valor = valor;

    }

    public No getAnterior(){
        return anterior;
    }

    public void setAnterior(No<T> anterior){
        this.anterior = anterior;

    }
}
