/**
 * Write a description of class Pilha here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pilha{

    private No<Bloco> topo;
    private int indice;
    private int baseX, baseY;
    private int tamanho=0;

    public void empilhar(Bloco bloco){
        bloco.setX(baseX);
        bloco.setY(baseY);
        No<Bloco> noBloco = new No<Bloco>(bloco);
        if(topo == null){
            topo = noBloco;
        }else{
            noBloco.setAnterior(topo);
            topo = noBloco;
        }
        tamanho++;
        baseY -= bloco.getImage().getHeight();
    }

    public Bloco olharTopo(){
        if(topo != null){
            return topo.getValor();
        }
        return null;
    }

    public Bloco desempilhar(){
        No<Bloco> cache = topo;
        if(cache != null){
            tamanho--;
            topo = topo.getAnterior();
            baseY += cache.getValor().getImage().getHeight();
            return cache.getValor();
        }
        return null;
    }

    public int getIndice(){
        return this.indice;
    }

    public void setIndice(int indice){
        this.indice = indice;
    }

    public int getBaseX(){
        return this.baseX;
    }

    public void setBaseX(int baseX){
        this.baseX = baseX;
    }

    public int getBaseY(){
        return this.baseY;
    }

    public void setBaseY(int baseY){
        this.baseY = baseY;
    }
    
    public int tamanho(){
        return tamanho;
    }
}
