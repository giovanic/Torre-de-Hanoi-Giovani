import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    private No<Pilha> pilhas;
    private final int NUMERO_COLUNAS = 3;
    private final int NUMERO_BLOCOS = 7;
    private Pilha base;

    private int larguraColuna;

    private Bloco blocoMove;
    private Pilha cachePilha;

    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        larguraColuna = this.getWidth()/NUMERO_COLUNAS;
        setBackground("fundo.png");

        for(int i = 0; i < NUMERO_COLUNAS; i++){
            Pilha pilha = new Pilha();
            No<Pilha> noPilha = new No<Pilha>(pilha);
            if(pilhas == null){
                pilhas = noPilha;
                base = pilha;
            }else{
                noPilha.setAnterior(pilhas);
                pilhas = noPilha;
            }
            pilha.setIndice(i+1);
            pilha.setBaseX((larguraColuna * (i+1)) - (larguraColuna/2));
            pilha.setBaseY(getHeight() - 10 );
        }

        for(int i = NUMERO_BLOCOS; i > 0; i--){
            Bloco bloco = new Bloco();
            bloco.setImage("bloco" + i + ".png");
            bloco.setPeso(i);
            base.empilhar(bloco);
            addObject(bloco, bloco.getX(), bloco.getY());
        }
    }

    public void act(){
        if(Greenfoot.mouseDragged(null)){
            MouseInfo mouse = Greenfoot.getMouseInfo();
            if(blocoMove == null){
                Actor actor = mouse.getActor();
                Bloco bloco = (Bloco) actor;
                if(actor != null){
                    No<Pilha> topo = pilhas;
                    do{
                        Pilha pilha = (Pilha)topo.getValor();
                        if(pilha.olharTopo() != null && pilha.olharTopo().equals(bloco)){
                            move(bloco, pilha);
                            break;
                        }
                        topo = topo.getAnterior();
                    }while(topo != null);
                }
            }else{
                blocoMove.setLocation(mouse.getX(), mouse.getY());
            }
        }else if(Greenfoot.mouseDragEnded(null) && blocoMove != null){
            MouseInfo mouse = Greenfoot.getMouseInfo();
            int indice = (int)Math.ceil((double)mouse.getX()/larguraColuna);
            if(indice < 1){
                indice = 1;
            }else if(indice > NUMERO_COLUNAS){
                indice = NUMERO_COLUNAS;
            }

            Pilha pilha = selecionarPilha(indice);
            if(pilha != null && !cachePilha.equals(pilha)){
                if(pilha.olharTopo() == null || pilha.olharTopo().getPeso() > blocoMove.getPeso()){
                    pilha.empilhar(cachePilha.desempilhar());
                    
                }
            }
            blocoMove.setLocation(blocoMove.getX(), blocoMove.getY());
            blocoMove = null;
            cachePilha = null;
        }
    }

    private Pilha selecionarPilha(int indice){
        No<Pilha> cache = pilhas;

        do{
            if(cache.getValor().getIndice() == indice){
                return cache.getValor();
            }
            cache = cache.getAnterior();
        }while(cache != null);
        return null;
    }

    private void move(Bloco bloco, Pilha pilha){
        blocoMove = bloco;
        cachePilha = pilha;
        removeObject(bloco);
        addObject(bloco, bloco.getX(), bloco.getY());
    }
    
    private void verificarVitoria(){
        No<Pilha> cache = pilhas;

        do{
            if(cache.getValor().tamanho() >= NUMERO_BLOCOS && !cache.getValor().equals(base)){
                JOptionPane.showMessageDialog(null, "Você venceu");
                Greenfoot.stop();
            }
            cache = cache.getAnterior();
        }while(cache != null);
    }
}
